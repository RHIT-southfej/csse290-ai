package AIGeneratedCode;

public enum Color {
    WHITE,
    RAINBOW
}
